function history = phasebeat_initHistory(history)
    
    history.trial.blockSections = [];
    history.timing.blockSections = [];
    
    history.timing.jitterQ = [];
    history.timing.actualITT = [];

end